# COMPASS
Comparison Of Models using Posterior Analysis in Simulation-based Settings
